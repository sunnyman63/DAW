<?php
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];
    $mensaje = $_POST["mensaje"];

    echo "Nombre: $nombre"."<br>";
    echo "Correo: $correo"."<br>";
    echo "Mensaje: $mensaje";
?>