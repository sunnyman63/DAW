<?php
    $alumnos = array(
        array("id" => "1000",
              "nombre" => "Miguel Torres",
              "edad" => "22"),
        array("id" => "2000",
              "nombre" => "Alejandro Romero",
              "edad" => "21"),
        array("id" => "3000",
              "nombre" => "Carlos Rodríguez",
              "edad" => "23"),
        array("id" => "4000",
              "nombre" => "Sergio Collado",
              "edad" => "20"));

    echo "<pre>";
    print_r($alumnos);
    echo "</pre>";
?>