<?php
    $nombres = array("Miguel Torres","Alejandro Romero","Carlos Rodríguez","Sergio Collado");
    echo "<pre>";
    print_r($nombres);
    echo "</pre>";
?>