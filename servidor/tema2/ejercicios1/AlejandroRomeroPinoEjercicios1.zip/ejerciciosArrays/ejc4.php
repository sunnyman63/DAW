<?php
    include ( 'ejc1.php');
    asort($nombres);
    echo "<br><pre>";
    print_r($nombres);
    echo "</pre>";
?>