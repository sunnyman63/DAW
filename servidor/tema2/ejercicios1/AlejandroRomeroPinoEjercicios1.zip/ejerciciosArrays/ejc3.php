<?php
    include ( 'ejc1.php');
    for($a=0;$a<count($nombres);$a++) {
        $cadena .=$nombres[$a]." ";
    }
    echo $cadena;
?>