<?php
    include ( 'ejc1.php');
    echo "<br>";
    echo "El array contiene ".count($nombres)." elementos.";
?>