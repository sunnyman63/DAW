<?php
    include ( 'ejc1.php');
    echo "Mi nombre (Alejandro Romero) se encuenta en la posición ".array_search("Alejandro Romero",$nombres);
?>