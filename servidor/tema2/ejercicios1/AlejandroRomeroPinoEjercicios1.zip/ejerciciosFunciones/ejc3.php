<?php
    function incrementar(&$n1){
        $n1++;
        echo $n1."<br>";
    }

    $n1 = 5;
    incrementar($n1);
    echo $n1;
?>