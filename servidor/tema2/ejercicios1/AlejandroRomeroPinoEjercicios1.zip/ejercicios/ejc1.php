<?php 
    $esp = "Uno, Dos, Tres, Cuatro, Cinco, Seis, Siete, Ocho, Nueve, Diez.";
    $eng = "One, Two, Three, Four, Five, Six, Seven, Eight, Nine, Ten.";

    $lengua = $_GET["lengua"];
    echo $$lengua;
?>